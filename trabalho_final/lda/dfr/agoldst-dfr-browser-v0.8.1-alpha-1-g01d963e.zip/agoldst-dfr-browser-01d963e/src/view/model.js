/*global view */
"use strict";
view.model = function () {
    return true;
};
